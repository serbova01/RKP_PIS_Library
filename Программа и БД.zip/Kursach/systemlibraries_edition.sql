-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: systemlibraries
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edition`
--

DROP TABLE IF EXISTS `edition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `edition` (
  `id` bigint NOT NULL,
  `isbn` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `image_name` varchar(255) DEFAULT NULL,
  `num_pages` int NOT NULL,
  `price` double NOT NULL,
  `year` int NOT NULL,
  `book_id` bigint DEFAULT NULL,
  `publ_house_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7q57m1a7u3voirj9k9ncugsdr` (`book_id`),
  KEY `FK8q5okkx4lagveosap7o0jvato` (`publ_house_id`),
  CONSTRAINT `FK7q57m1a7u3voirj9k9ncugsdr` FOREIGN KEY (`book_id`) REFERENCES `book` (`id`),
  CONSTRAINT `FK8q5okkx4lagveosap7o0jvato` FOREIGN KEY (`publ_house_id`) REFERENCES `publ_house` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edition`
--

LOCK TABLES `edition` WRITE;
/*!40000 ALTER TABLE `edition` DISABLE KEYS */;
INSERT INTO `edition` VALUES (1,'978-5-389-13861-2','Но ощущение безысходности свойственно не только индивидуалистам и бунтарям, но и маленькому человеку. Так, в повести «Муму», написанной Тургеневым на основе реальных событий, личная драма Герасима поднимается до уровня общечеловеческой трагедии.','mumu.jpg',352,159,2018,3,3),(2,'978-5-389-10818-9','Жизнь Гарри Поттера меняется до неузнаваемости в одиннадцатый день рождения, когда Рубеус Огрид, гигант с похожими на жуков глазами, вручает ему письмо с фантастическими известиями.',NULL,246,1990,2016,1,1),(3,'978-5-17-122250-5','Сказки Александра Сергеевича Пушкина – это вечная классика русской детской литературы. ',NULL,32,280,2021,2,4);
/*!40000 ALTER TABLE `edition` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-30 10:07:49
