package com.example.SystemLibraries;

import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MainServer {
    @Autowired
    private SubscriberRepository subscriberRepository;
    @Autowired
    private LibraryRepository libraryRepository;
    @Autowired
    private SubsnumberRepository subsnumberRepository;
    @Autowired
    private AuthorRepository authorRepository;
    @Autowired
    private BookRepository bookRepository;
    @Autowired
    private CycleRepository cycleRepository;
    @Autowired
    private DepartmentRepository departmentRepository;
    @Autowired
    private EditionRepository editionRepository;
    @Autowired
    private GenreRepository genreRepository;
    @Autowired
    private HistoryReaderRepository historyReaderRepository;
    @Autowired
    private PublHouseRepository publHouseRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private CopyBookRepository copyBookRepository;

    public List<Author> findAllAuthors() {
        return authorRepository.findAll();
    }
    public Author findAuthorById(Long id) {
        return authorRepository.findById(id).get();
    }
    public List<Book> findAllBooks() {
        return bookRepository.findAll();
    }
    public Book findBookById(Long id) {
        return bookRepository.findById(id).get();
    }
    public List<Cycle> findAllCycles() {
        return cycleRepository.findAll();
    }
    public Cycle findCycleById(Long id) {
        return cycleRepository.findById(id).get();
    }
    public List<Genre> findAllGenres() {
        return genreRepository.findAll();
    }
    public Genre findGenreById(Long id) {
        return genreRepository.findById(id).get();
    }
    public List<Department> findAllDeps() {
        return departmentRepository.findAll();
    }
    public Department findDepById(Long id) {
        return departmentRepository.findById(id).get();
    }
    public List<Edition> findAllEditions() {
        return editionRepository.findAll();
    }
    public Edition findEditionById(Long id) {
        return editionRepository.findById(id).get();
    }
    public List<HistoryReader> findAllHRs() {
        return historyReaderRepository.findAll();
    }
    public HistoryReader findHRById(Long id) {
        return historyReaderRepository.findById(id).get();
    }
    public List<PublHouse> findAllPHs() {
        return publHouseRepository.findAll();
    }
    public PublHouse findPHById(Long id) {
        return publHouseRepository.findById(id).get();
    }
    public List<User> findAllUsers() {
        return userRepository.findAll();
    }
    public User findUserById(Long id) {
        return userRepository.findById(id).get();
    }
    public List<Subscriber> findAllSubs() {
        return subscriberRepository.findAll();
    }
    public Subscriber findSubsById(Long id) {
        return subscriberRepository.findById(id).get();
    }
    public List<Library> findAllLibs() {
        return libraryRepository.findAll();
    }
    public Library findLibById(Long id) {

        return (libraryRepository.findById(id).get());
    }
    public List<CopyBook> findAllCBs() {
        return copyBookRepository.findAll();
    }
    public CopyBook findCBById(Long id) {
        return (copyBookRepository.findById(id).get());
    }
    private List<Subsnumber> findAllSubsNum() {
        return  subsnumberRepository.findAll();
    }

    public void addLibrary(Library library) {
        libraryRepository.save(library);
    }
    public void addSubsriber(Subscriber subscriber) {
        subscriberRepository.save(subscriber);
    }
    public void addSubsNumber(Subsnumber subsnumber) {
        List<Subsnumber> list = findAllSubsNum().stream().filter(sn -> sn.getLibrary() == subsnumber.getLibrary()).collect(Collectors.toList());
        int maxSubsNumber = 0;
        for (Subsnumber sn : list){
            if (maxSubsNumber > sn.getNumber())
                maxSubsNumber = sn.getNumber();
        }
        subsnumber.setNumber(maxSubsNumber+1);
        subsnumber.setRelevance(true);
        subsnumberRepository.save(subsnumber);
    }

    public Library findLibByAddress(Library library) {
        List<Library> list = libraryRepository.findAll();
        if (list != null){
            Library library2 = list.stream().filter(l-> l.getCity().equals(library.getCity()) && l.getStreet().equals(library.getStreet()) &&
                    l.getHouse().equals(library.getHouse())).findAny().orElse(null);
            return library2;
        }
        return null;
    }

    public Subscriber findSubsByPhNumber(String phonenumber) {
        List<Subscriber> list = subscriberRepository.findAll();
        if (list != null){
            Subscriber item = list.stream().filter(s-> s.getPhonenumber().equals(phonenumber)).findAny().orElse(null);
            return  item;
        }
        return  null;
    }

    public Author findAuthorByFIO(Author author) {
        Author author1 = authorRepository.findAll().stream().filter(s-> s.getFirstname().equals(author.getFirstname()) &&
                s.getSecondname().equals(author.getSecondname())).findAny().orElse(null);
        return author1;
    }
    public void addAuthor(Author author) {
        authorRepository.save(author);
    }

    public void deleteSubs(Long id) {
        List<Subsnumber> subsnumbers = findAllSubsNum().stream().filter(s->
                s.getSubscriber().getId() == id).collect(Collectors.toList());
        List<HistoryReader> historyReaders = findAllHRs().stream().filter(h->
                h.getSubscriber().getId() == id).collect(Collectors.toList());
        Subscriber subscriber = findSubsById(id);
        if (subscriber.getEmail() != null){
            User user = findUserByEmail(subscriber.getEmail());
            deleteUser(user.getId());
        }
        subsnumbers.forEach(s-> deleteSubsNum(s.getId()));
        historyReaders.forEach(h->deleteHR(h.getId()));
        subscriberRepository.deleteById(id);
    }

    private void deleteUser(Long id) {

        userRepository.deleteById(id);
    }

    private void deleteSubsNum(Long id) {
        subsnumberRepository.deleteById(id);
    }

    public void deleteLib(Long id) {
        List<Department> departments = findAllDeps().stream().filter(d->
                d.getLibrary().getId() == id).collect(Collectors.toList());
        List<Subsnumber> subsnumbers = findAllSubsNum().stream().filter(s->
                s.getLibrary().getId() == id).collect(Collectors.toList());
        departments.forEach(d->deleteDepartment(d.getId()));
        subsnumbers.forEach(s->deleteSubsNum(s.getId()));

        libraryRepository.deleteById(id);
    }

    public void deleteAuthor(Long id) {
        Author author = findAuthorById(id);
        List<Book> books = findAllBooks().stream().filter(b -> b.getAuthors().contains(author)).collect(Collectors.toList());
        for (Book book : books) {
            book.getAuthors().remove(author);
            if (book.getAuthors().size() == 0)
                deleteBook(book.getId());
        }
        authorRepository.deleteById(id);
    }

    public Book findBookByNameAndAuthors(Book book) {
        Book book1 = bookRepository.findAll().stream().filter(s-> s.getName().equals(book.getName()) &&
                s.getAuthorsStr().equals(book.getAuthorsStr())).findAny().orElse(null);
        return book1;
    }

    public void saveBook(Book book) {
        bookRepository.save(book);
    }

    public void deleteBook(Long id) {
        List<Edition> editions = findAllEditions().stream().filter(e->e.getBook().getId() == id)
                .collect(Collectors.toList());
        editions.forEach(h->deleteEdition(h.getId()));
        bookRepository.deleteById(id);
    }

    public CopyBook findCopyBookByInvNumber(CopyBook copyBook) {
        CopyBook copyBook1 = copyBookRepository.findAll().stream().filter(s-> s.getInvNumber().equals(copyBook.getInvNumber())).findAny().orElse(null);
        return copyBook1;
    }

    public void saveCopyBook(CopyBook copyBook) {
        copyBookRepository.save(copyBook);
    }

    public void deleteCopyBook(Long id) {
        List<HistoryReader> historyReaders = findAllHRs().stream().filter(h->
                h.getCopyBook().getId() == id).collect(Collectors.toList());
        historyReaders.forEach(h->deleteHR(h.getId()));
        copyBookRepository.deleteById(id);
    }

    public Cycle findCycleByName(Cycle cycle) {
        Cycle cycle1 = cycleRepository.findAll().stream().filter(s-> s.getName().equals(cycle.getName())).findAny().orElse(null);
        return cycle1;
    }

    public void saveCycle(Cycle cycle) {
        cycleRepository.save(cycle);
    }

    public void deleteCycle(Long id) {
        List<Book> books = findAllBooks().stream().filter(b->b.getCycle()!= null && b.getCycle().getId() == id)
                .collect(Collectors.toList());
        books.forEach(b->deleteBook(b.getId()));
        cycleRepository.deleteById(id);
    }

    public Department findDepByNameAndLib(Department department) {
        Department department1 = departmentRepository.findAll().stream().filter(s-> s.getName().equals(department.getName()) &&
                s.getLibrary().getId().equals(department.getLibrary().getId())).findAny().orElse(null);
        return department1;
    }

    public void saveDepartment(Department department) {
        departmentRepository.save(department);
    }

    public void deleteDepartment(Long id) {
        List<CopyBook> copyBooks = findAllCBs().stream().filter(b->
                b.getDepartment().getId() == id).collect(Collectors.toList());
        copyBooks.forEach(b->deleteCopyBook(b.getId()));
        departmentRepository.deleteById(id);
    }

    public void saveEdition(Edition edition) {
        editionRepository.save(edition);
    }

    public void deleteEdition(Long id) {
        List<CopyBook> copyBooks = findAllCBs().stream().filter(c->c.getEdition().getId() == id)
                .collect(Collectors.toList());
        copyBooks.forEach(h->deleteCopyBook(h.getId()));
        editionRepository.deleteById(id);
    }

    public Genre findGenreByName(Genre genre) {
        Genre genre1 = genreRepository.findAll().stream().filter(s-> s.getName().equals(genre.getName())).findAny().orElse(null);
        return genre1;
    }

    public void saveGenre(Genre genre) {
        genreRepository.save(genre);
    }

    public void deleteGenre(Long id) {
        List<Book> books = findAllBooks().stream().filter(b->
                b.getGenre().getId() == id).collect(Collectors.toList());
        books.forEach(b->deleteBook(b.getId()));
        genreRepository.deleteById(id);
    }

    public void saveHR(HistoryReader historyReader) {
        historyReaderRepository.save(historyReader);
    }

    public void deleteHR(Long id) {
        HistoryReader historyReader = findHRById(id);
        if (historyReader.isRelevance()){
            historyReader.getCopyBook().setStatus("в наличии");
            saveCopyBook(historyReader.getCopyBook());
        }
        historyReaderRepository.deleteById(id);
    }

    public Book findBookByMaxId() {
        List<Book> books = bookRepository.findAll();
        long maxId = 0;
        for (Book b:books ) {
            if(maxId < b.getId())
                maxId = b.getId();
        }
        long finalMaxId = maxId;
        Book book = findBookById(maxId);
        return book;
    }

    public PublHouse findPHByName(PublHouse publHouse) {
        PublHouse publHouse1 = publHouseRepository.findAll().stream().filter(s-> s.getName().equals(publHouse.getName())).findAny().orElse(null);
        return publHouse1;
    }

    public void savePH(PublHouse publHouse) {
        publHouseRepository.save(publHouse);
    }

    public void deletePH(Long id) {
        List<Edition> editions = findAllEditions().stream().filter(e->
                e.getPublHouse().getId() == id).collect(Collectors.toList());
        editions.forEach(e->deleteEdition(e.getId()));
        publHouseRepository.deleteById(id);
    }

    public User findUserByLoginForReg(String login) {
        if (!login.equals("admin") && !login.contains("librarian")){
            return userRepository.findByUsername(login);
        }
        return null;
    }
    public User findUserByLogin(String login) {
        return userRepository.findByUsername(login);
    }
    public void saveUser(User user) {
        userRepository.save(user);
    }

    public Subscriber findSubsByEmail(String email) {
        if (email != null){
            Subscriber subscriber = subscriberRepository.findAll().stream().filter(s->
                    s.getEmail()!= null && s.getEmail().equals(email)).findAny().orElse(null);
            return subscriber;
        }
        return null;
    }

    public User findUserByEmail(String email) {
        User user = userRepository.findAll().stream().filter(s-> s.getEmail().equals(email)).findAny().orElse(null);
        return user;
    }
}
