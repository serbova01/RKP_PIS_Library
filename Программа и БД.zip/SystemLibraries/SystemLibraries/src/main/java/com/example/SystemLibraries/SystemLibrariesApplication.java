package com.example.SystemLibraries;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SystemLibrariesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SystemLibrariesApplication.class, args);
	}

}
