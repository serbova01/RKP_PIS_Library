package com.example.SystemLibraries.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

import javax.sql.DataSource;

@Configuration
@EnableWebSecurity
class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    @Autowired
    private DataSource dataSource;
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .antMatchers("/css/**", "/img/**", "/home", "/registration", "/login").permitAll()
                /*.antMatchers("/library/list", "/library/create", "/library/edit/?", "/department/edit/?",
                        "/department/details/?", "/library/details/?", "/author/?", "/book/?", "/copyBook/?", "/cycle/?",
                        "/department/list", "/department/create", "/edition/?", "/genre/?", "/historyReader/?",
                        "/publHouse/?", "/subscriber/?", "/user/listSubs").hasAnyRole("ADMIN")
                .antMatchers("/library/details/?", "/author/?", "/book/?", "/copyBook/?", "/cycle/?", "/department/list",
                        "/department/create", "/edition/?", "/genre/?", "/historyReader/?", "/publHouse/?", "/subscriber/?",
                        "/user/listSubs").hasAnyRole("LIB")
                .antMatchers("/subscriber/details/?", "/subscriber/edit/?").hasAnyRole("USER")*/
                .anyRequest().authenticated()
                .and()
                .formLogin().loginPage("/login").permitAll()
                .and()
                .logout().permitAll();
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.jdbcAuthentication()
                .dataSource(dataSource)
                .passwordEncoder(NoOpPasswordEncoder.getInstance())
                .usersByUsernameQuery("select username, password, enabled from user_system where username=?")
                .authoritiesByUsernameQuery("select u.username, ur.roles from user_system u " +
                        "inner join user_role ur on u.id = ur.user_id where u.username=?");
    }
}