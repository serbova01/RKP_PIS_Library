package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.MainServer;
import com.example.SystemLibraries.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/author")
public class AuthorController {
    @Autowired
    private MainServer mainServer;

    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<Author> list = mainServer.findAllAuthors();
            model.addAttribute("authors", list);
            model.addAttribute("user", user);
            return "author/list";
        }
        return "redirect:/home";
    }
    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            Author author = mainServer.findAuthorById(id);
            model.addAttribute("author", author);
            model.addAttribute("user", user);
            return "author/details";
        }
        return "redirect:/home";
    }

    @GetMapping("/create")
        public String create(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            model.addAttribute("author", new Author());
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "author/create";
        }
        return "redirect:/home";
    }

    @PostMapping("/create")
    public String create(@ModelAttribute Author author, Model model){
        if(author.isNullField()){
            model.addAttribute("message", "Заполните обязательные поля: Фамилия и Имя.");
            return "author/create";
        }
        if(mainServer.findAuthorByFIO(author) == null){
            mainServer.addAuthor(author);
            return "redirect:/author/list";
        }else{
            model.addAttribute("message", "Автор с таким ФИО уже существует.");
            return "author/create";
        }
    }
    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            model.addAttribute("author", mainServer.findAuthorById(id));
            model.addAttribute("user", user);
            return "author/edit";
        }
        return "redirect:/home";
    }

    @PostMapping("/edit")
    public String edit(@ModelAttribute Author author, Model model){
        Author authorCkeck = mainServer.findAuthorByFIO(author);
        if(author.isNullField()){
            model.addAttribute("message", "Заполните обязательные поля: Фамилия и Имя.");
            return "author/edit/" + author.getId();
        }
        if (authorCkeck != null && authorCkeck.getId() != author.getId()){
            model.addAttribute("message", "Автор с таким ФИО уже существует.");
            return "author/edit/" + author.getId();
        }else{
            mainServer.addAuthor(author);
            return "redirect:/author/list";
        }
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && user.getRoles().contains(Role.ADMIN)){

            mainServer.deleteAuthor(id);
            return "redirect:/author/list";
        }
        return "redirect:/home";
    }
}
