package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.MainServer;
import com.example.SystemLibraries.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/book")
public class BookController {
    @Autowired
    private MainServer mainServer;

    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<Book> list = mainServer.findAllBooks();
            model.addAttribute("books", list);
            model.addAttribute("user", user);
            return "book/list";
        }
        return "redirect:/home";
    }
    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            Book book = mainServer.findBookById(id);
            model.addAttribute("book", book);
            model.addAttribute("user", user);
            return "book/details";
        }
        return "redirect:/home";
    }

    @GetMapping("/create")
    public String create(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<Cycle> cycles = mainServer.findAllCycles();
            List<Genre> genres = mainServer.findAllGenres();
            model.addAttribute("book", new Book());
            model.addAttribute("cycles", cycles);
            model.addAttribute("genres", genres);
            model.addAttribute("user", user);
            return "book/create";
        }
        return "redirect:/home";
    }

    @PostMapping("/create")
    public String create(@ModelAttribute Book book, Model model){
        //if(mainServer.findBookByNameAndAuthors(book) == null){
        if (book.isNullFields()){
            model.addAttribute("message", "Заполните обязательные поля: Название.");
            return "book/create";
        }
            mainServer.saveBook(book);
            return "redirect:/book/addAuthors/" + book.getId();
        //}else{
            //model.addAttribute("message", "Произведение с таким названием и списком авторов уже существует.");
            //return "book/create";
        //}
    }

    @GetMapping("/addAuthors/{id}")
    public String addAuthors(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            Book book = mainServer.findBookById(id);
            List<Author> authors = mainServer.findAllAuthors();
            authors = authors.stream().filter(a -> !book.getAuthors().contains(a)).collect(Collectors.toList());
            model.addAttribute("book", book);
            model.addAttribute("authors", authors);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "book/addAuthors";
        }
        return "redirect:/home";
    }
    @GetMapping("/addListAuthors/{idBook}/{idAuthor}")
    public String addAuthors(Model model, @PathVariable("idBook") Long idBook, @PathVariable("idAuthor") Long idAuthor, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            Book book = mainServer.findBookById(idBook);
            book.getAuthors().add(mainServer.findAuthorById(idAuthor));
            mainServer.saveBook(book);
            List<Author> authors = mainServer.findAllAuthors();
            model.addAttribute("book", book);
            model.addAttribute("authors", authors);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "redirect:/book/addAuthors/" + book.getId();
        }else
            return "redirect:/home";
    }
    @GetMapping("/deleteListAuthors/{idBook}/{idAuthor}")
    public String deleteAuthors(Model model, @PathVariable("idBook") Long idBook, @PathVariable("idAuthor") Long idAuthor, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            Book book = mainServer.findBookById(idBook);
            book.getAuthors().remove(mainServer.findAuthorById(idAuthor));
            mainServer.saveBook(book);
            List<Author> authors = mainServer.findAllAuthors();
            model.addAttribute("book", book);
            model.addAttribute("authors", authors);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "redirect:/book/addAuthors/" + book.getId();
        }else
            return "redirect:/home";

    }

    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            Cycle[] cycles = mainServer.findAllCycles().toArray(new Cycle[0]);
            Genre[] genres = mainServer.findAllGenres().toArray(new Genre[0]);
            model.addAttribute("book", mainServer.findBookById(id));
            model.addAttribute("cycles", cycles);
            model.addAttribute("genres", genres);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "book/edit";
        }else
            return "redirect:/home";
    }

    @PostMapping("/edit")
    public String edit(@ModelAttribute Book book, Model model){
        Book bookCheck = mainServer.findBookByNameAndAuthors(book);
        if (book.isNullFields()){
            model.addAttribute("message", "Заполните обязательные поля: Название.");
            return "book/edit/" + book.getId();
        }
        if (bookCheck != null && bookCheck.getId() != book.getId()){
            model.addAttribute("book", book);
            model.addAttribute("message", "Произведение с таким названием и списком авторов уже существует.");
            return "book/edit/" + book.getId();
        }else{
            mainServer.saveBook(book);
            return "redirect:/book/list";
        }
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && user.getRoles().contains(Role.ADMIN)){

            mainServer.deleteBook(id);
            return "redirect:/book/list";
        }else
            return "redirect:/home";

    }
}
