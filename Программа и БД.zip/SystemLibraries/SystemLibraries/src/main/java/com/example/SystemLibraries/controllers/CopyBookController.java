package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.MainServer;
import com.example.SystemLibraries.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/copyBook")
public class CopyBookController {
    @Autowired
    private MainServer mainServer;

    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<CopyBook> list = mainServer.findAllCBs();
            if (user.getRoles().contains(Collections.singleton(Role.LIB))){
                list = list.stream().filter(cb -> cb.getDepartment().getLibrary().getId() == user.getLibrary().getId()).collect(Collectors.toList());
            }
            model.addAttribute("copyBooks", list);
            model.addAttribute("user", user);
            return "copyBook/list";
        }else
            return "redirect:/home";

    }

    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            CopyBook copyBook = mainServer.findCBById(id);
            model.addAttribute("copyBook", copyBook);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "copyBook/details";
        }else
            return "redirect:/home";

    }

    @GetMapping("/create")
    public String create(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<Edition> editions = mainServer.findAllEditions();
            List<Department> departments = mainServer.findAllDeps();
            model.addAttribute("editions", editions);
            model.addAttribute("departments", departments);
            model.addAttribute("copyBook", new CopyBook());
            model.addAttribute("user", user);
            return "copyBook/create";
        }else
            return "redirect:/home";
    }

    @PostMapping("/create")
    public String create(@ModelAttribute CopyBook copyBook, Model model){
        if (copyBook.getInvNumber() == null || copyBook.getInvNumber().trim().length() < 1){
            model.addAttribute("message", "Заполните обязательное поле: Инвентарный номер.");
            return "copyBook/create";
        }
        if(mainServer.findCopyBookByInvNumber(copyBook) == null){
            copyBook.setStatus("в наличии");
            mainServer.saveCopyBook(copyBook);
            return "redirect:/copyBook/list";
        }else{
            model.addAttribute("message", "Экземпляр книги с таким инвентарным номером уже существует.");
            return "copyBook/create";
        }
    }
    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<Edition> editions = mainServer.findAllEditions();
            List<Department> departments = mainServer.findAllDeps();
            List<String> statuses = new ArrayList<String>();
            if (user.getRoles().contains(Collections.singleton(Role.LIB))){
                departments = departments.stream().filter(d -> d.getLibrary().getId() == user.getLibrary().getId())
                        .collect(Collectors.toList());
            }
            statuses.add("в наличии");
            statuses.add("списана");
            statuses.add("выдана");
            model.addAttribute("editions", editions);
            model.addAttribute("departments", departments);
            model.addAttribute("statuses", statuses);
            model.addAttribute("copyBook", mainServer.findCBById(id));
            model.addAttribute("user", user);
            return "copyBook/edit";
        }else
            return "redirect:/home";

    }

    @PostMapping("/edit")
    public String edit(@ModelAttribute CopyBook copyBook, Model model){
        if (copyBook.getInvNumber() == null || copyBook.getInvNumber().trim().length() < 1){
            model.addAttribute("message", "Заполните обязательное поле: Инвентарный номер.");
            return "copyBook/edit/" + copyBook.getId();
        }
        CopyBook copyBookCheck = mainServer.findCopyBookByInvNumber(copyBook);
        if (copyBookCheck != null && copyBookCheck.getId() != copyBook.getId()){
            model.addAttribute("copyBook", copyBook);
            model.addAttribute("message", "Экземпляр книги с таким инвентарным номером уже существует.");
            return "copyBook/edit/" + copyBook.getId();
        }else{
            mainServer.saveCopyBook(copyBook);
            return "redirect:/copyBook/list";
        }
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && user.getRoles().contains(Role.ADMIN)){

            mainServer.deleteCopyBook(id);
            return "redirect:/copyBook/list";
        }else
            return "redirect:/home";
    }
    @GetMapping("/write_off/{id}")
    public String write_off(@PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            CopyBook copyBook = mainServer.findCBById(id);
            copyBook.setStatus("списана");
            mainServer.saveCopyBook(copyBook);
            return "redirect:/copyBook/list";
        }else
            return "redirect:/home";

    }
}
