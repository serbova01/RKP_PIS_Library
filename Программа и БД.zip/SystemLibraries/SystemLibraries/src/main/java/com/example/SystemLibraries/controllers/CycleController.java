package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.MainServer;
import com.example.SystemLibraries.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/cycle")
public class CycleController {
    @Autowired
    private MainServer mainServer;

    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<Cycle> list = mainServer.findAllCycles();
            model.addAttribute("cycles", list);
            model.addAttribute("user", user);
            return "cycle/list";
        }else
            return "redirect:/home";

    }
    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            Cycle cycle = mainServer.findCycleById(id);
            model.addAttribute("cycle", cycle);
            model.addAttribute("user", user);
            return "cycle/details";
        }else
            return "redirect:/home";

    }

    @GetMapping("/create")
    public String create(Model model, Principal principal){
        model.addAttribute("cycle", new Cycle());
        model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
        return "cycle/create";
    }

    @PostMapping("/create")
    public String create(@ModelAttribute Cycle cycle, Model model){
        if (cycle.getName() == null || cycle.getName().trim().length() < 2){
            model.addAttribute("message", "Заполните обязательное поле: Название.");
            return "cycle/create";
        }
        if(mainServer.findCycleByName(cycle) == null){
            mainServer.saveCycle(cycle);
            return "redirect:/cycle/list";
        }else{
            model.addAttribute("message", "Цикл с таким названием уже существует.");
            return "cycle/create";
        }
    }
    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            model.addAttribute("cycle", mainServer.findCycleById(id));
            model.addAttribute("user", user);
            return "cycle/edit";
        }else
            return "redirect:/home";

    }

    @PostMapping("/edit")
    public String edit(@ModelAttribute Cycle cycle, Model model, Principal principal){
        Cycle cycleCheck = mainServer.findCycleByName(cycle);
        if (cycle.getName() == null || cycle.getName().trim().length() < 2){
            model.addAttribute("message", "Заполните обязательное поле: Название.");
            return "cycle/edit/" + cycle.getId();
        }
        if (cycleCheck != null && cycleCheck.getId() != cycle.getId()){
            model.addAttribute("cycle", cycle);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            model.addAttribute("message", "Цикл с таким названием уже существует.");
            return "cycle/edit/" + cycle.getId();
        }else{
            mainServer.saveCycle(cycle);
            return "redirect:/cycle/list";
        }
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && user.getRoles().contains(Role.ADMIN)){

            mainServer.deleteCycle(id);
            return "redirect:/cycle/list";
        }else
            return "redirect:/home";

    }
}
