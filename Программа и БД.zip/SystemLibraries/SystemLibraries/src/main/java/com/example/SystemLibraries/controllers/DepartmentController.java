package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.MainServer;
import com.example.SystemLibraries.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/department")
public class DepartmentController {
    @Autowired
    private MainServer mainServer;

    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<Department> list = mainServer.findAllDeps();
            model.addAttribute("departments", list);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "department/list";
        }else
            return "redirect:/home";

    }
    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            Department department = mainServer.findDepById(id);
            model.addAttribute("department", department);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "department/details";
        }else
            return "redirect:/home";

    }

    @GetMapping("/create")
    public String create(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<Library> libraries = mainServer.findAllLibs();
            model.addAttribute("libraries", libraries);
            model.addAttribute("department", new Department());
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "department/create";
        }else
            return "redirect:/home";

    }

    @PostMapping("/create")
    public String create(@ModelAttribute Department department, Model model){
        if (department.getName() == null || department.getName().trim().length()<=1){
            model.addAttribute("message", "Заполните обязательное поле: Название.");
            return "department/create";
        }
        if(mainServer.findDepByNameAndLib(department) == null){
            mainServer.saveDepartment(department);
            return "redirect:/department/list";
        }else{
            model.addAttribute("message", "Отдел с таким названием уже существует.");
            return "department/create";
        }

    }
    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<Library> libraries = mainServer.findAllLibs();
            model.addAttribute("libraries", libraries);
            model.addAttribute("department", mainServer.findDepById(id));
            model.addAttribute("user", user);
            return "department/edit";
        }else
            return "redirect:/home";

    }

    @PostMapping("/edit")
    public String edit(@ModelAttribute Department department, Model model, Principal principal){
        if (department.getName() == null || department.getName().trim().length() < 2){
            model.addAttribute("message", "Заполните обязательное поле: Название.");
            return "department/edit/" + department.getId();
        }
        User user = mainServer.findUserByLogin(principal.getName());
        if (user.getRoles().contains(Role.LIB)){
            department.setLibrary(user.getLibrary());
        }
        Department depCheck = mainServer.findDepByNameAndLib(department);
        if (depCheck != null && depCheck.getId() != department.getId()){
            model.addAttribute("department", department);
            model.addAttribute("user", user);
            model.addAttribute("message", "Отдел с таким названием уже существует.");
            return "department/edit/" + department.getId();
        }else{
            mainServer.saveDepartment(department);
            return "redirect:/department/list";
        }
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && user.getRoles().contains(Role.ADMIN)){

            mainServer.deleteDepartment(id);
            return "redirect:/department/list";
        }else
            return "redirect:/home";

    }
}
