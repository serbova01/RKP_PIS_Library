package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.MainServer;
import com.example.SystemLibraries.models.*;
import org.apache.tomcat.util.http.fileupload.impl.FileSizeLimitExceededException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.security.Principal;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

@Controller
@RequestMapping("/edition")
public class EditionController {
    @Autowired
    private MainServer mainServer;

    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<Edition> list = mainServer.findAllEditions();
            model.addAttribute("editions", list);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "edition/list";
        }else
            return "redirect:/home";

    }
    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            Edition edition = mainServer.findEditionById(id);
            HashMap<Library, Integer> map = new HashMap<>();
            if (user.getRoles().contains(Collections.singleton(Role.ADMIN))){
                for(CopyBook cb : edition.getCopyBooks()){
                    if (map.containsKey(cb.getDepartment().getLibrary())){
                        map.put(cb.getDepartment().getLibrary(), map.get(cb.getDepartment().getLibrary()) + 1);
                    }else{
                        map.put(cb.getDepartment().getLibrary(), 1);
                    }
                }
            }
            model.addAttribute("maps", map);
            model.addAttribute("edition", edition);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "edition/details";
        }else
            return "redirect:/home";

    }

    @GetMapping("/create")
    public String create(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<PublHouse> publHouses = mainServer.findAllPHs();
            List<Book> books = mainServer.findAllBooks();
            model.addAttribute("publHouses", publHouses);
            model.addAttribute("books", books);
            EditionWithImage edition = new EditionWithImage();
            model.addAttribute("ewi", edition);
            model.addAttribute("user", user);
            return "edition/create";
        }else
            return "redirect:/home";

    }

    @RequestMapping(path = "/create", method = RequestMethod.POST, consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    public String create(@ModelAttribute EditionWithImage ewi, Model model) throws IOException {
        if (ewi.isNullFields()){
            model.addAttribute("message", "Заполните корректными данными обязательные поля: " +
                    "ISBN, Год издания, Цена и Количество страниц.");
            return "edition/create";
        }
        if (ewi.getFile().getOriginalFilename().length() < 1){
            model.addAttribute("message", "Загрузите изображение обложки.");
            return "edition/create";
        }
        try{
            Edition edition = new Edition();
            edition.setImageName(ewi.getImageName());
            edition.setDescription(ewi.getDescription());
            edition.setBook(ewi.getBook());
            edition.setPrice(ewi.getPrice());
            edition.setISBN(ewi.getISBN());
            edition.setYear(ewi.getYear());
            edition.setNumPages(ewi.getNumPages());
            edition.setPublHouse(ewi.getPublHouse());
            edition.setDescription(edition.getDescription().trim());
            edition = ewi.setImage(edition);
            mainServer.saveEdition(edition);
            return "redirect:/edition/list";
        }catch (Exception ex){
            model.addAttribute("message", ex.getMessage());
            return "edition/create";
        }
        //}
    }

    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<PublHouse> publHouses = mainServer.findAllPHs();
            List<Book> books = mainServer.findAllBooks();
            EditionWithImage edition = new EditionWithImage(mainServer.findEditionById(id));
            model.addAttribute("publHouses", publHouses);
            model.addAttribute("books", books);
            model.addAttribute("ewi", edition);
            model.addAttribute("user", user);
            return "edition/edit";
        }else
            return "redirect:/home";

    }

    @RequestMapping(path = "/edit", method = RequestMethod.POST, consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    public String edit(@ModelAttribute EditionWithImage ewi, Model model) throws IOException {
        if (ewi.isNullFields()){
            model.addAttribute("message", "Заполните корректными данными обязательные поля: " +
                    "ISBN, Год издания, Цена и Количество страниц.");
            return "edition/edit/" + ewi.getId();
        }
        if (ewi.getImageName() == null && ewi.getFile().getOriginalFilename().length() < 1){
            model.addAttribute("message", "Загрузите изображение обложки.");
            return "edition/edit/" + ewi.getId();
        }
        try{
            Edition edition = new Edition();
            edition.setId(ewi.getId());
            edition.setImageName(ewi.getImageName());
            edition.setDescription(ewi.getDescription());
            edition.setBook(ewi.getBook());
            edition.setPrice(ewi.getPrice());
            edition.setISBN(ewi.getISBN());
            edition.setYear(ewi.getYear());
            edition.setNumPages(ewi.getNumPages());
            edition.setPublHouse(ewi.getPublHouse());
            edition.setDescription(edition.getDescription().trim());
            edition = ewi.setImage(edition);
            mainServer.saveEdition(edition);
            return "redirect:/edition/list";
        }catch (FileSizeLimitExceededException ex){
            model.addAttribute("message", ex.getMessage());
            return "edition/edit/" + ewi.getId();
        }
        //}
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && user.getRoles().contains(Role.ADMIN)){
            mainServer.deleteEdition(id);
            return "redirect:/edition/list";
        }else
            return "redirect:/home";

    }
}
