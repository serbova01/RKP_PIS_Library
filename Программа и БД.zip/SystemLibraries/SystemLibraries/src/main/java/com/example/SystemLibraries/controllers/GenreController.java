package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.MainServer;
import com.example.SystemLibraries.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/genre")
public class GenreController {
    @Autowired
    private MainServer mainServer;

    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<Genre> list = mainServer.findAllGenres();
            model.addAttribute("genres", list);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "genre/list";
        }else
            return "redirect:/home";

    }
    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            Genre genre = mainServer.findGenreById(id);
            model.addAttribute("genre", genre);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "genre/details";
        }else
            return "redirect:/home";

    }

    @GetMapping("/create")
    public String create(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            model.addAttribute("genre", new Genre());
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "genre/create";
        }else
            return "redirect:/home";

    }

    @PostMapping("/create")
    public String create(@ModelAttribute Genre genre, Model model){
        if (genre.getName()==null || genre.getName().trim().length() < 2){
            model.addAttribute("message", "Заполните обязательное поле: Название");
            return "genre/create";
        }
        if(mainServer.findGenreByName(genre) == null){
            mainServer.saveGenre(genre);
            return "redirect:/genre/list";
        }else{
            model.addAttribute("message", "Жанр с таким названием уже существует.");
            return "genre/create";
        }
    }
    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            model.addAttribute("genre", mainServer.findGenreById(id));
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "genre/edit";
        }else
            return "redirect:/home";

    }

    @PostMapping("/edit")
    public String edit(@ModelAttribute Genre genre, Model model){
        if (genre.getName()==null || genre.getName().trim().length() < 2){
            model.addAttribute("message", "Заполните обязательное поле: Название");
            return "genre/edit/" + genre.getId();
        }
        Genre genreCheck = mainServer.findGenreByName(genre);
        if (genreCheck != null && genreCheck.getId() != genre.getId()){
            model.addAttribute("genre", genre);
            model.addAttribute("message", "Жанр с таким названием уже существует.");
            return "genre/edit/" + genre.getId();
        }else{
            mainServer.saveGenre(genre);
            return "redirect:/genre/list";
        }
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && user.getRoles().contains(Role.ADMIN)){
            mainServer.deleteGenre(id);
            return "redirect:/genre/list";
        }else
            return "redirect:/home";

    }
}
