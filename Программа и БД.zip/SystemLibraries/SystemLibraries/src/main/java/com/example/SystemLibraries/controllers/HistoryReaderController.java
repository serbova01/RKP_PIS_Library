package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.MainServer;
import com.example.SystemLibraries.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/historyReader")
public class HistoryReaderController {
    @Autowired
    private MainServer mainServer;

    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<HistoryReader> list = mainServer.findAllHRs();
            if (user.getRoles().contains(Collections.singleton(Role.LIB))){
                list = list.stream().filter(hr -> hr.getCopyBook().getDepartment().getLibrary().getId() ==
                        user.getLibrary().getId()).collect(Collectors.toList());
            }
            model.addAttribute("historyReaders", list);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "historyReader/list";
        }else
            return "redirect:/home";

    }
    @GetMapping("/issuedList")
    public String issuedList(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<HistoryReader> list = mainServer.findAllHRs().stream().filter(hr -> hr.isRelevance()).collect(Collectors.toList());
            if (user.getRoles().contains(Collections.singleton(Role.LIB))){
                list = list.stream().filter(hr -> hr.getCopyBook().getDepartment().getLibrary().getId() ==
                        user.getLibrary().getId()).collect(Collectors.toList());
            }
            model.addAttribute("historyReaders", list);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "historyReader/list";
        }else
            return "redirect:/home";

    }
    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            HistoryReader historyReader = mainServer.findHRById(id);
            model.addAttribute("historyReader", historyReader);
            model.addAttribute("user", user);
            return "historyReader/details";
        }else
            return "redirect:/home";

    }

    @GetMapping("/create")
    public String create(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<CopyBook> copyBooks = mainServer.findAllCBs().stream().filter(c -> c.getStatus().equals("в наличии")).collect(Collectors.toList());
            if (user.getRoles().contains(Collections.singleton(Role.LIB))){
                copyBooks = copyBooks.stream().filter(cb -> cb.getDepartment().getLibrary().getId() ==
                        user.getLibrary().getId()).collect(Collectors.toList());
            }
            List<Subscriber> subscribers = mainServer.findAllSubs();
            model.addAttribute("copyBooks", copyBooks);
            model.addAttribute("subscribers", subscribers);
            model.addAttribute("historyReader", new HistoryReader());
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "historyReader/create";
        }else
            return "redirect:/home";

    }

    @PostMapping("/create")
    public String create(@ModelAttribute HistoryReader historyReader, Model model){
        //if(mainServer.findGenreByName(genre) == null){
        historyReader.setDateIssue(LocalDate.now());
        historyReader.setDateReturn(LocalDate.now().plusMonths(1));
        historyReader.setRelevance(true);
            mainServer.saveHR(historyReader);
            return "redirect:/historyReader/list";
        //}else
            //return "redirect:/historyReader/create";
    }
    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            HistoryReader hr = mainServer.findHRById(id);
            List<CopyBook> copyBooks = mainServer.findAllCBs().stream().filter(c -> c.getStatus().equals("в наличии") &&
                    c.getInvNumber() != hr.getCopyBook().getInvNumber()).collect(Collectors.toList());
            if (user.getRoles().contains(Collections.singleton(Role.LIB))){
                copyBooks = copyBooks.stream().filter(cb -> cb.getDepartment().getLibrary().getId() ==
                        user.getLibrary().getId()).collect(Collectors.toList());
            }
            List<Subscriber> subscribers = mainServer.findAllSubs();
            if (user.getRoles().contains(Collections.singleton(Role.LIB))){
                subscribers = subscribers.stream().filter(s ->
                                s.getSubsNumbers().stream().filter(sn ->
                                        sn.getLibrary().getId() == user.getLibrary().getId()).collect(Collectors.toList()).size() > 0)
                        .collect(Collectors.toList());
            }
            model.addAttribute("copyBooks", copyBooks);
            model.addAttribute("subscribers", subscribers);
            model.addAttribute("historyReader", hr);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "historyReader/edit";
        }else
            return "redirect:/home";

    }

    @PostMapping("/edit")
    public String edit(@ModelAttribute HistoryReader historyReader, Model model){
        //HistoryReader genreCheck = mainServer.findGenreByName(historyReader);
        //if (genreCheck != null && genreCheck.getId() != historyReader.getId()){
            //model.addAttribute("historyReader", historyReader);
            //return "redirect:/historyReader/edit/" + historyReader.getId();
        //}else{
            mainServer.saveHR(historyReader);
            return "redirect:/historyReader/list";
        //}
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && user.getRoles().contains(Role.ADMIN)){
            mainServer.deleteHR(id);
            return "redirect:/historyReader/list";
        }else
            return "redirect:/home";

    }
    @GetMapping("/extendBook/{idHR}")
    public String extendBook( @PathVariable("idHR") Long idHR, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null){
            HistoryReader hr = mainServer.findHRById(idHR);
            hr.setDateReturn(hr.getDateReturn().plusMonths(1));
            mainServer.saveHR(hr);
            return "redirect:/historyReader/list";
        }else
            return "redirect:/home";

    }
}
