package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.MainServer;
import com.example.SystemLibraries.models.Library;
import com.example.SystemLibraries.models.Role;
import com.example.SystemLibraries.models.Subscriber;
import com.example.SystemLibraries.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/library")
public class LibraryController {
    @Autowired
    private MainServer mainServer;

    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && user.getRoles().contains(Role.ADMIN)){
            List<Library> list = mainServer.findAllLibs();
            model.addAttribute("libraries", list);
            model.addAttribute("user", user);
            return "library/list";
        }else
            return "redirect:/home";

    }

    @GetMapping("/create")
    public String createGet(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && user.getRoles().contains(Role.ADMIN)){
            model.addAttribute("library", new Library());
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "library/create";
        }else
            return "redirect:/home";

    }

    @PostMapping("/create")
    public String createPost(@ModelAttribute Library library, Model model){
        if (library.isNullFields()){
            model.addAttribute("message", "Заполните обязательные поля: Название, Городской номер, Email, " +
                    "Город, Улицу, Дом");
            return "library/create";
        }
        if (mainServer.findLibByAddress(library) == null){
            mainServer.addLibrary(library);
            List<Library> list = mainServer.findAllLibs();
            model.addAttribute("libraries", list);
            return "redirect:/library/list";
        }else{
            model.addAttribute("message", "Библиотека с таким адресом уже существует.");
            model.addAttribute("library", library);
            return "library/create";
        }
    }

    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            Library library = mainServer.findLibById(id);
            user = mainServer.findAllUsers().stream().filter(u -> u.getLibrary().getId() == id &&
                    u.getRoles().contains(Role.LIB)).findAny().get();
            model.addAttribute("library", library);
            model.addAttribute("librarian", user);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "library/details";
        }else
            return "redirect:/home";

    }

    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && user.getRoles().contains(Role.ADMIN)){
            model.addAttribute("library", mainServer.findLibById(id));
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "library/edit";
        }else
            return "redirect:/home";

    }

    @PostMapping("/edit")
    public String edit(@ModelAttribute Library library, Model model){
        if (library.isNullFields()){
            model.addAttribute("message", "Заполните обязательные поля: Название, Городской номер, Email, " +
                    "Город, Улицу, Дом");
            return "library/edit/" + library.getId();
        }
        Library libCkeck = mainServer.findLibByAddress(library);
        if (libCkeck != null && libCkeck.getId() != library.getId()){
            model.addAttribute("library", library);
            model.addAttribute("message", "Библиотека с таким адресом уже существует.");
            return "library/edit/" + library.getId();
        }else{
            mainServer.addLibrary(library);
            return "redirect:/library/list";
        }
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && user.getRoles().contains(Role.ADMIN)){

            mainServer.deleteLib(id);
            return "redirect:/library/list";
        }else
            return "redirect:/home";

    }
}
