package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.MainServer;
import com.example.SystemLibraries.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

@Controller
public class MainController {
    @Autowired
    private MainServer mainServer;

    @GetMapping("/home")
    public String list(Model model, Principal principal){
        List<Edition> editions = mainServer.findAllEditions();
        HashMap<Genre, List<Edition>> map = new HashMap<>();
        for(Edition ed : editions){
            List<Edition> list;
            if (map.containsKey(ed.getBook().getGenre())){
                list = map.get(ed.getBook().getGenre());
            }else{
                list =  new ArrayList<Edition>();
            }
            list.add(ed);
            map.put(ed.getBook().getGenre(), list);
        }
        model.addAttribute("maps", map);
        if (principal != null){
            User user = mainServer.findUserByLogin(principal.getName());
            Subscriber subscriber = mainServer.findSubsByEmail(user.getEmail());
            if (subscriber != null)
                model.addAttribute("subscriber", subscriber);
            model.addAttribute("user", user);
        }
        return "home";
    }

    @GetMapping("/registration")
    public String registration(){
        return "registration";
    }
    @PostMapping("/registration")
    public String registration(@ModelAttribute RegUser regUser, Model model){
        if (regUser.isNullFields()){
            model.addAttribute("message", "Заполните обязательные поля: Логин, Email, Пароль и Номер телефона.");
            return "registration";
        }
        User user1 = mainServer.findUserByLoginForReg(regUser.getLogin());
        if (user1 != null){
            model.addAttribute("message", "Пользователь с таким Логином уже существует.");
            return "registration";
        }
        user1 = mainServer.findUserByEmail(regUser.getEmail());
        if (user1 != null){
            model.addAttribute("message", "Пользователь с таким email-ом уже существует.");
            return "registration";
        }
        User user = new User();
        user.setUsername(regUser.getLogin());
        user.setEmail(regUser.getEmail());
        user.setPassword(regUser.getPassword());
        user.setEnabled(true);
        user.setRoles(Collections.singleton(Role.USER));
        mainServer.saveUser(user);
        Subscriber subscriber = mainServer.findSubsByPhNumber(regUser.getPhnumber());
        if (subscriber != null){
            subscriber.setEmail(regUser.getEmail());
            mainServer.addSubsriber(subscriber);
            return "redirect:/login";
        }else{
            subscriber.setPhonenumber(regUser.getPhnumber());
            subscriber.setEmail(regUser.getEmail());
            mainServer.addSubsriber(subscriber);
            return "redirect:/subscriber/create/" + subscriber.getId();
        }
    }


}
