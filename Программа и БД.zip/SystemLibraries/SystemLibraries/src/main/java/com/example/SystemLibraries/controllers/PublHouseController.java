package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.MainServer;
import com.example.SystemLibraries.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/publhouse")
public class PublHouseController {
    @Autowired
    private MainServer mainServer;

    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<PublHouse> list = mainServer.findAllPHs();
            model.addAttribute("publHouses", list);
            model.addAttribute("user", user);
            return "publhouse/list";
        }else
            return "redirect:/home";

    }
    @GetMapping("/create")
    public String createGet(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            model.addAttribute("publHouse", new PublHouse());
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "publhouse/create";
        }else
            return "redirect:/home";

    }

    @PostMapping("/create")
    public String createPost(@ModelAttribute PublHouse publHouse, Model model){

        if (publHouse.isNullFields()){
            model.addAttribute("message", "Заполните обязательные поля: Название и Город");
            return "publhouse/create";
        }
        if (mainServer.findPHByName(publHouse) == null){
            publHouse = setPHShortNameCity(publHouse);
            mainServer.savePH(publHouse);
            List<PublHouse> list = mainServer.findAllPHs();
            model.addAttribute("publHouses", list);
            return "redirect:/publhouse/list";
        }else{
            model.addAttribute("publHouse", publHouse);
            model.addAttribute("message", "Издательство с таким названием уже существует.");
            return "publhouse/create";
        }
    }

    private PublHouse setPHShortNameCity(PublHouse publHouse) {
        String[] shortCityName1 = publHouse.getLongNameCity().split("-");
        publHouse.setShortNameCity("");
        for (int i=0; i<shortCityName1.length; i++){
            String[] shortCityName2 = shortCityName1[i].split(" ");
            for (int i1=0; i1<shortCityName1.length; i1++){
                publHouse.setShortNameCity(publHouse.getShortNameCity() + shortCityName2[i].toCharArray()[0]);
            }
        }
        return publHouse;
    }

    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            PublHouse publHouse = mainServer.findPHById(id);
            model.addAttribute("publHouse", publHouse);
            model.addAttribute("user", user);
            return "publhouse/details";
        }else
            return "redirect:/home";

    }

    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            model.addAttribute("publHouse", mainServer.findPHById(id));
            model.addAttribute("user", user);
            return "publhouse/edit";
        }else
            return "redirect:/home";

    }

    @PostMapping("/edit")
    public String edit(@ModelAttribute PublHouse publHouse, Model model){
        if (publHouse.isNullFields()){
            model.addAttribute("message", "Заполните обязательные поля: Название и Город");
            return "publhouse/edit/" + publHouse.getId();
        }
        PublHouse phCheck = mainServer.findPHByName(publHouse);
        if (phCheck != null && phCheck.getId() != publHouse.getId()){
            model.addAttribute("publHouse", publHouse);
            model.addAttribute("message", "Издательство с таким названием уже существует.");
            return "publhouse/edit/" + publHouse.getId();
        }else{
            publHouse = setPHShortNameCity(publHouse);
            mainServer.savePH(publHouse);
            return "redirect:/publhouse/list";
        }
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            mainServer.deletePH(id);
            return "redirect:/publhouse/list";
        }else
            return "redirect:/home";

    }
}
