package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.MainServer;
import com.example.SystemLibraries.models.*;
import com.example.SystemLibraries.repositories.SubscriberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/subscriber")
public class SubscriberController {
    @Autowired
    private MainServer mainServer;

    @GetMapping("/list")
    public String listS(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<Subscriber> allSubscribers = mainServer.findAllSubs();
            model.addAttribute("subscribers", allSubscribers);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "subscriber/list";
        }else
            return "redirect:/home";

    }

    @GetMapping("/details/{id}")
    public String details(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null){
            Subscriber subscriber = mainServer.findSubsById(id);
            model.addAttribute("subscriber", subscriber);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "subscriber/details";
        }else
            return "redirect:/home";

    }

    @GetMapping("/create/{id}")
    public String createGet(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null){
            model.addAttribute("subscriber", mainServer.findSubsById(id));
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "subscriber/create";
        }else
            return "redirect:/home";

    }

    @GetMapping("/create")
    public String createGet(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            model.addAttribute("subscriber", new Subscriber());
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "subscriber/create";
        }else
            return "redirect:/home";

    }

    @PostMapping("/createPost")
    public String createPost(@ModelAttribute Subscriber subscriber, Model model){
        if (subscriber.isNullFields()){
            model.addAttribute("message", "Заполните обязательные поля: Фамилия, Имя, Номер телефона, " +
                    "Город, Улица и Дом.");
            return "subscriber/create";
        }
        if (mainServer.findSubsByPhNumber(subscriber.getPhonenumber()) != null){
            model.addAttribute("subscriber", subscriber);
            model.addAttribute("message", "Абонент с таким номером телефона уже существует.");
            return "subscriber/create";
        }else{
            mainServer.addSubsriber(subscriber);
            return "redirect:/subscriber/addLib/" + subscriber.getId();
        }
    }

    @GetMapping("/addLib/{id}")
    public String addLib(Model model, @PathVariable("id") Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null){
            List<Library> list = mainServer.findAllLibs();
            Subscriber subscriber = mainServer.findSubsById(id);

            model.addAttribute("libraries", list);
            model.addAttribute("subscriber", subscriber);
            model.addAttribute("user", user);
            return "subscriber/addLib";
        }else
            return "redirect:/home";

    }
    @GetMapping("/addLib/{idSubs}/{idLib}")
    public String addLib(Model model, @PathVariable("idSubs") Long idSubs, @PathVariable("idLib") Long idLib, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null){
            if (idSubs>0 && idLib>0){
                Subsnumber subsnumber = new Subsnumber();
                subsnumber.setLibrary(mainServer.findLibById(idLib));
                subsnumber.setSubscriber(mainServer.findSubsById(idSubs));
                mainServer.addSubsNumber(subsnumber);

                List<Subscriber> list = mainServer.findAllSubs();
                model.addAttribute("subscribers", list);
                model.addAttribute("user", user);
                return "subscriber/list";
            }
            return "subscriber/addLib/" + idSubs;
        }else
            return "redirect:/home";

    }

    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null){
            model.addAttribute("subscriber", mainServer.findSubsById(id));
            model.addAttribute("user", user);
            return "subscriber/edit";
        }else
            return "redirect:/home";

    }

    @PostMapping("/edit")
    public String edit(@ModelAttribute Subscriber subscriber, Model model){
        if (subscriber.isNullFields()){
            model.addAttribute("message", "Заполните обязательные поля: Фамилия, Имя, Номер телефона, " +
                    "Город, Улица и Дом.");
            return "subscriber/edit/" + subscriber.getId();
        }
        Subscriber subsCkeck = mainServer.findSubsByPhNumber(subscriber.getPhonenumber());
        if (subsCkeck != null && subsCkeck.getId() != subscriber.getId()){
            model.addAttribute("subscriber", subscriber);
            model.addAttribute("message", "Абонент с таким номером телефона уже существует.");
            return "subscriber/edit/" + subscriber.getId();
        }else{
            mainServer.addSubsriber(subscriber);
            return "redirect:/subscriber/list";
        }
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && user.getRoles().contains(Role.ADMIN)){
            mainServer.deleteSubs(id);
            return "redirect:/subscriber/list";
        }else
            return "redirect:/home";

    }

    @GetMapping("/extendBook/{idSubs}/{idHR}")
    public String extendBook(@PathVariable("idSubs") Long idSubs, @PathVariable("idHR") Long idHR, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            HistoryReader hr = mainServer.findHRById(idHR);
            hr.setDateReturn(hr.getDateReturn().plusMonths(1));
            mainServer.saveHR(hr);
            return "redirect:/subscriber/details/" + idSubs;
        }else
            return "redirect:/home";

    }

    @GetMapping("/issueBook/{id}")
    public String issueBook(@PathVariable Long id, Principal principal, Model model){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            List<CopyBook> list = mainServer.findAllCBs().stream().filter(c -> c.getStatus().equals("в наличии")).collect(Collectors.toList());
            if (user.getLibrary() != null && user.getRoles().contains(Role.LIB)){
                list = list.stream().filter(c -> c.getDepartment().getLibrary().getId() == user.getLibrary().getId()).collect(Collectors.toList());
            }
            Subscriber subscriber = mainServer.findSubsById(id);
            model.addAttribute("subscriber",subscriber);
            model.addAttribute("copyBooks", list);
            model.addAttribute("user", user);
            return "subscriber/issueBook";
        }else
            return "redirect:/home";

    }
    @GetMapping("/issueBook/{idSubs}/{idCB}")
    public String issueBook(Model model, @PathVariable("idSubs") Long idSubs, @PathVariable("idCB") Long idCB, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && !user.getRoles().contains(Role.USER)){
            HistoryReader historyReader = new HistoryReader();
            CopyBook copyBook = mainServer.findCBById(idCB);
            historyReader.setSubscriber(mainServer.findSubsById(idSubs));
            historyReader.setCopyBook(copyBook);
            historyReader.setDateIssue(LocalDate.now());
            historyReader.setDateReturn(LocalDate.now().plusMonths(1));
            historyReader.setRelevance(true);
            mainServer.saveHR(historyReader);
            copyBook.setStatus("выдана");
            mainServer.saveCopyBook(copyBook);
            return "redirect:/subscriber/issueBook/" + idSubs;
        }else
            return "redirect:/home";

    }
}
