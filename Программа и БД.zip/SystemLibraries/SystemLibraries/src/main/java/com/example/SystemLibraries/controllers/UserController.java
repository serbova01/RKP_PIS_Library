package com.example.SystemLibraries.controllers;

import com.example.SystemLibraries.MainServer;
import com.example.SystemLibraries.models.RegUser;
import com.example.SystemLibraries.models.Role;
import com.example.SystemLibraries.models.Subscriber;
import com.example.SystemLibraries.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.security.Principal;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    private MainServer mainServer;

    @GetMapping("/list")
    public String list(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && user.getRoles().contains(Role.ADMIN)){
            List<User> list = mainServer.findAllUsers().stream().filter(u -> !u.getUsername().equals("admin") &&
                    u.getRoles().contains(Role.LIB)).collect(Collectors.toList());
            model.addAttribute("users", list);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "user/listLibrarian";
        }else
            return "redirect:/home";

    }

    @GetMapping("/listSubs")
    public String listSubs(Model model, Principal principal){
        User user =  mainServer.findUserByLogin(principal.getName());
        if (user != null && user.getRoles().contains(Role.ADMIN)){
            List<User> list = mainServer.findAllUsers().stream().filter(u -> !u.getUsername().equals("admin") &&
                    u.getRoles().contains(Role.USER)).collect(Collectors.toList());
            model.addAttribute("users", list);
            model.addAttribute("user", mainServer.findUserByLogin(principal.getName()));
            return "user/listSubs";
        }else
            return "redirect:/home";

    }
}
