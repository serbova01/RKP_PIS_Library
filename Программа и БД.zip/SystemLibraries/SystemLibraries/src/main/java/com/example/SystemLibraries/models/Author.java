package com.example.SystemLibraries.models;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.sun.istack.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;
import org.aspectj.bridge.IMessage;
import org.springframework.lang.Nullable;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@Entity
public class Author {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String firstname;
    private String secondname;
    @Nullable
    private String lastname;
    @ManyToMany
    @JsonManagedReference
    private List<Book> books;

    public boolean isNullField() {
        return (firstname == null || firstname.trim().length() < 2 || secondname == null || secondname.trim().length() < 2);
    }
}
