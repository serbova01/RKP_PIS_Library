package com.example.SystemLibraries.models;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.lang.Nullable;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@Entity
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    @Nullable
    @ManyToOne
    @JsonBackReference
    private Cycle cycle;
    @ManyToOne
    @JsonBackReference
    private Genre genre;
    @ManyToMany
    @JsonBackReference
    private List<Author> authors;
    @OneToMany(mappedBy = "book")
    @JsonManagedReference
    private List<Edition> editions;

    public String getAuthorsStr(){
        String str = "";
        for (Author author: authors) {
            str+= author.getFirstname() + " " + author.getSecondname().toCharArray()[0] + ".";
            if (author.getLastname() != null && author.getLastname().length() > 1){
                str += " " + author.getLastname().toCharArray()[0] + ".";
            }
            str += ", ";
        }
        if (authors.size()>0)
            str = str.subSequence(0, str.length()-2).toString();
        return str;
    }

    public String getNameAndAuthorStr(){
        return name + " " + getAuthorsStr();
    }

    public boolean isNullFields() {
        return name == null || name.trim().length() < 2;
    }
}
