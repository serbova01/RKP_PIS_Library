package com.example.SystemLibraries.models;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@Entity
public class CopyBook {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String invNumber;
    private String status;
    @ManyToOne
    @JsonBackReference
    private Edition edition;
    @ManyToOne
    @JsonBackReference
    private Department department;
    @OneToMany(mappedBy = "copyBook")
    @JsonManagedReference
    private List<HistoryReader> historyReaders;

    public String getName(){
        return invNumber + " " + edition.getName()+ " " + department.getName() + " " + department.getLibrary().getName();
    }
}
