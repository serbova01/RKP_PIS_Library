package com.example.SystemLibraries.models;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@Entity
public class Edition {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String ISBN;
    private int year;
    private String description;
    private double price;
    private int numPages;
    private String imageName;
    //private MultipartFile fileImage;
    @ManyToOne
    @JsonBackReference
    private PublHouse publHouse;
    @ManyToOne
    @JsonBackReference
    private Book book;
    @OneToMany(mappedBy = "edition")
    //@JoinColumn(name = "SNIdLib")
    @JsonManagedReference
    private List<CopyBook> copyBooks;

    public String getName(){
        return book.getNameAndAuthorStr() + " " + publHouse.getName() + " " + ISBN;
    }

}
