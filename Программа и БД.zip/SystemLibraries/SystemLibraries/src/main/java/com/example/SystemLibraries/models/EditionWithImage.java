package com.example.SystemLibraries.models;

import org.apache.tomcat.util.http.fileupload.impl.FileSizeLimitExceededException;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class EditionWithImage {
    private long id;
    private String ISBN;
    private int year;
    private String description;
    private double price;
    private int numPages;
    private String imageName;
    private PublHouse publHouse;
    private Book book;
    private MultipartFile file;
    public boolean isNullFields() {
        return (ISBN == null || ISBN.trim().length() < 2 || year < 1000 || price < 1 || numPages < 2);
    }

    public EditionWithImage() {
    }

    public EditionWithImage(Edition edition) {
        this.id = edition.getId();
        this.ISBN = edition.getISBN();
        this.year = edition.getYear();
        this.description = edition.getDescription();
        this.price = edition.getPrice();
        this.numPages = edition.getNumPages();
        this.imageName = edition.getImageName();
        this.publHouse = edition.getPublHouse();
        this.book = edition.getBook();
    }

    public Edition setImage(Edition edition) throws IOException,FileSizeLimitExceededException {
        StringBuilder fileNames = new StringBuilder();
        Path resourceDirectory = Paths.get("src","main","resources", "static", "img", "images");
        Path fileNameAndPath = Paths.get(resourceDirectory.toAbsolutePath().toString(), file.getOriginalFilename());
        fileNames.append(file.getOriginalFilename());
        if (edition.getImageName() != null){
            File file1 = new File(String.format(fileNameAndPath.toAbsolutePath().toString() + "/" + imageName));
            if (!file1.exists()){
                Files.write(fileNameAndPath, file.getBytes());
            }else{
                return edition;
            }
        }else{
            Files.write(fileNameAndPath, file.getBytes());
        }
        //edition.setImageName(file.getName());
        edition.setImageName(fileNames.toString());
        return edition;
    }

    public EditionWithImage(String ISBN, int year, String description, double price, int numPages, String imageName,
                            PublHouse publHouse, Book book, MultipartFile file) {
        this.ISBN = ISBN;
        this.year = year;
        this.description = description;
        this.price = price;
        this.numPages = numPages;
        this.imageName = imageName;
        this.publHouse = publHouse;
        this.book = book;
        this.file = file;
    }

    public EditionWithImage(long id, String ISBN, int year, String description, double price, int numPages,
                            String imageName, PublHouse publHouse, Book book, MultipartFile file) {
        this.id = id;
        this.ISBN = ISBN;
        this.year = year;
        this.description = description;
        this.price = price;
        this.numPages = numPages;
        this.imageName = imageName;
        this.publHouse = publHouse;
        this.book = book;
        this.file = file;
    }

    public EditionWithImage(String ISBN, int year, String description, double price, int numPages, String imageName, PublHouse publHouse, Book book) {
        this.ISBN = ISBN;
        this.year = year;
        this.description = description;
        this.price = price;
        this.numPages = numPages;
        this.imageName = imageName;
        this.publHouse = publHouse;
        this.book = book;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getNumPages() {
        return numPages;
    }

    public void setNumPages(int numPages) {
        this.numPages = numPages;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public PublHouse getPublHouse() {
        return publHouse;
    }

    public void setPublHouse(PublHouse publHouse) {
        this.publHouse = publHouse;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public MultipartFile getFile() {
        return file;
    }

    public void setFile(MultipartFile file) {
        this.file = file;
    }

}
