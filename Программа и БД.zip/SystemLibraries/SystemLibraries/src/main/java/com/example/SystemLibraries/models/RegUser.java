package com.example.SystemLibraries.models;

public class RegUser {
    public String login;
    public String email;
    public String password;
    public String phnumber;

    public RegUser(String login, String email, String password, String phnumber) {
        this.login = login;
        this.email = email;
        this.password = password;
        this.phnumber = phnumber;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhnumber() {
        return phnumber;
    }

    public void setPhnumber(String phnumber) {
        this.phnumber = phnumber;
    }

    public boolean isNullFields() {
        return (login == null || login.trim().length() < 2 || email == null || email.trim().length() < 2 ||
                password == null || password.trim().length() < 2 || phnumber == null || phnumber.trim().length() < 2);
    }
}
