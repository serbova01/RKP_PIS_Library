package com.example.SystemLibraries.models;


public enum Role {
    USER, LIB,ADMIN
}
