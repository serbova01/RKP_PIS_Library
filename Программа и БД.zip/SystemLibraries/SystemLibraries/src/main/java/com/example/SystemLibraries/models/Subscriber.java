package com.example.SystemLibraries.models;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.lang.Nullable;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@Entity
public class Subscriber {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String firstname;
    private String secondname;
    @Nullable
    private String lastname;
    private String phonenumber;
    @Nullable
    private String email;
    private String city;
    private String street;
    private String house;
    @Nullable
    private String flat;
    @OneToMany(mappedBy = "subscriber")
    @JsonManagedReference
    private List<Subsnumber> subsNumbers;
    @OneToMany(mappedBy = "subscriber")
    @JsonManagedReference
    private List<HistoryReader> historyReaders;

    public String getFIO(){
        String str = "";
        str += firstname + " " + secondname.toCharArray()[0] + ". ";
        if (lastname != null){
            str += lastname.toCharArray()[0] + ". ";
        }
        return str;
    }

    public String getFIOAndPhNumber(){
        return getFIO() + " - " + phonenumber;
    }

    public boolean isNullFields() {
        return (firstname == null || firstname.trim().length() < 2 || secondname == null || secondname.trim().length() < 2 ||
                phonenumber == null || phonenumber.trim().length() < 2 || city == null || city.trim().length() < 2 ||
                street == null || street.trim().length() < 2 || house == null || house.trim().length() < 2);
    }
}
