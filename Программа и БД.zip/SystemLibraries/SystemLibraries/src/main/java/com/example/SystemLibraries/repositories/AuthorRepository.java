package com.example.SystemLibraries.repositories;

import com.example.SystemLibraries.models.Author;
import com.example.SystemLibraries.models.Subsnumber;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuthorRepository  extends JpaRepository<Author, Long> {
}
