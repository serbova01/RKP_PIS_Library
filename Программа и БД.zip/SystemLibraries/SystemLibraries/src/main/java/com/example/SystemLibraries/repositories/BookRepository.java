package com.example.SystemLibraries.repositories;

import com.example.SystemLibraries.models.Book;
import com.example.SystemLibraries.models.Subsnumber;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookRepository extends JpaRepository<Book, Long> {
}
