package com.example.SystemLibraries.repositories;

import com.example.SystemLibraries.models.Book;
import com.example.SystemLibraries.models.CopyBook;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CopyBookRepository  extends JpaRepository<CopyBook, Long> {
}
