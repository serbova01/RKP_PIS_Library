package com.example.SystemLibraries.repositories;

import com.example.SystemLibraries.models.Book;
import com.example.SystemLibraries.models.Edition;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EditionRepository extends JpaRepository<Edition, Long> {
}
