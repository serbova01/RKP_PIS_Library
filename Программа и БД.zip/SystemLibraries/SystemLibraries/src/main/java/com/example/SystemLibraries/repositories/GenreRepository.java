package com.example.SystemLibraries.repositories;

import com.example.SystemLibraries.models.Book;
import com.example.SystemLibraries.models.Genre;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GenreRepository extends JpaRepository<Genre, Long> {
}
