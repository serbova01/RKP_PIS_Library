package com.example.SystemLibraries.repositories;

import com.example.SystemLibraries.models.Book;
import com.example.SystemLibraries.models.HistoryReader;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HistoryReaderRepository extends JpaRepository<HistoryReader, Long> {
}
