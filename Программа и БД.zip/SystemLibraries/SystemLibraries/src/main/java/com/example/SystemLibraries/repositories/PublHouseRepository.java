package com.example.SystemLibraries.repositories;

import com.example.SystemLibraries.models.Book;
import com.example.SystemLibraries.models.PublHouse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PublHouseRepository extends JpaRepository<PublHouse, Long> {
}
