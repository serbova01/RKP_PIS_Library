package com.example.SystemLibraries.repositories;

import com.example.SystemLibraries.models.Subscriber;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface SubscriberRepository  extends JpaRepository<Subscriber, Long> {

}
