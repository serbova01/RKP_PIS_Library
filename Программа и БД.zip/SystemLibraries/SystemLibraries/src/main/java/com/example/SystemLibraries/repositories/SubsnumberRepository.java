package com.example.SystemLibraries.repositories;

import com.example.SystemLibraries.models.Subsnumber;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SubsnumberRepository extends JpaRepository<Subsnumber, Long> {
}
