package com.example.SystemLibraries;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SystemLibrariesApplicationTests {

	@Test
	void contextLoads() {
	}

}
